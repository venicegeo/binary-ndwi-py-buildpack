from .version import __version__
from beachfront.logger import init_logger

init_logger()
