from potrace._potrace import *


__version__ = "0.1"
