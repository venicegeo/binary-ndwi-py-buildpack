import os
import glob
import argparse
import json
import logging

import gippy
import gippy.algorithms as alg
import beachfront.mask as bfmask
import beachfront.process as bfproc
import beachfront.vectorize as bfvec
from bfalg_ndwi.version import __version__

logger = logging.getLogger(__file__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())


def process(img1, img2, qband=None, coastmask=False, save=False):
    """ Process data from indir to outdir """

    geoimg = img1.add_band(img2[0])
    if qband is not None:
        fout = geoimg.basename() + '_cloudmask.tif' if save else ''
        maskimg = bfmask.create_mask_from_bitmask(qband, filename=fout)
        geoimg.add_mask(maskimg[0] == 1)

    # calculate NWDI
    geoimg.set_bandnames(['green', 'nir'])
    fout = geoimg.basename() + '_ndwi.tif' if save else ''
    imgout = alg.indices(geoimg, ['ndwi'], filename=fout)

    # mask with coastline
    if coastmask:
        # open coastline vector
        fname = os.path.join(os.path.dirname(__file__), 'coastmask.shp')
        fout = geoimg.basename() + '_coastmask.tif' if save else ''
        imgout = bfmask.mask_with_vector(imgout, (fname, ''), filename=fout)

    # calculate optimal threshold
    threshold = bfproc.otsu_threshold(imgout[0])

    # save thresholded image
    if save:
        fout = geoimg.basename() + '_thresh.tif'
        imgout2 = gippy.GeoImage.create_from(imgout, filename=fout, dtype='byte')
        (imgout[0] > threshold).save(imgout2[0])

    # vectorize threshdolded (ie now binary) image
    coastline = bfvec.potrace(imgout[0] > threshold)

    # convert coordinates to GeoJSON
    geojson = bfvec.to_geojson(coastline, source=geoimg.basename())
    if save:
        fout = geoimg.basename() + '_coastline.geojson'
        with open(fout, 'w') as f:
            f.write(json.dumps(geojson))
    return geojson


def open_from_directory(dirin='', ext='.TIF'):
    """ Open collection of files from a directory """
    # inspect directory for imagery, mask, take band ratio
    fnames = glob.glob(os.path.join(dirin, '*%s' % ext))
    prefix = os.path.commonprefix(fnames)
    print(prefix)
    # geoimg = gippy.GeoImage(fnames[0:1], nodata=0)


def main():
    """ Parse command line arguments and call process() """
    desc = 'Beachfront Algorithm: NDWI (v%s)' % __version__
    dhf = argparse.ArgumentDefaultsHelpFormatter
    parser = argparse.ArgumentParser(description=desc, formatter_class=dhf)

    parser.add_argument('--b1', help='Green (or Blue or Coastal Band)', required=True)
    parser.add_argument('--b2', help='NIR Band', required=True)
    parser.add_argument('--fout', help='Output filename for geojson', default='coastline.geojson')
    parser.add_argument('--outdir', help='Save intermediate files to this dir (otherwise temp)', default='')

    parser.add_argument('--qband', help='Quality band (used to mask clouds)')
    parser.add_argument('--coastmask', help='Mask non-coastline areas', default=False, action='store_true')
    parser.add_argument('--version', help='Print version and exit', action='version', version=__version__)

    args = parser.parse_args()

    try:
        band1 = gippy.GeoImage(args.b1)
        band2 = gippy.GeoImage(args.b2)
        qband = args.qband if args.qband is None else gippy.GeoImage(args.qband)

        geojson = process(band1, band2, qband=qband, coastmask=args.coastmask)

        # save output
        with open(args.fout, 'w') as f:
            f.write(json.dumps(geojson))
        logger.info('bfalg_ndwi complete: %s' % os.path.abspath(args.fout))
    except Exception, e:
        logger.error('bfalg_ndwi error: %s' % str(e))
        from traceback import format_exc
        logger.error(format_exc())


if __name__ == "__main__":
    main()
